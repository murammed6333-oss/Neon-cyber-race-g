NEON CYBER-RACER GP - GITHUB PAGES DOSYALARI

DOSYALAR
- index.html : Oyunun tanıtım sitesi
- game.html  : Oyunun oynanabilir HTML sürümü

GITHUB'A YÜKLEME
1. GitHub'da kendi deponu aç.
2. Add file > Upload files seç.
3. Bu klasördeki index.html ve game.html dosyalarını birlikte seçip yükle.
4. Commit changes düğmesine bas.
5. Settings > Pages bölümünü aç.
6. Deploy from a branch seç.
7. Branch: main, Folder: / (root) seçip Save'e bas.
8. GitHub Pages adresin birkaç dakika içinde oluşur.

NOT
OYUNU İNDİR düğmesi APK henüz hazır olmadığı için bilerek pasif bırakıldı.
TEST ET düğmesi game.html dosyasını açar.
Oyun, kullandığı bazı çevrimiçi kütüphaneler nedeniyle internet bağlantısı gerektirebilir.
